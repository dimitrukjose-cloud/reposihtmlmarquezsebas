# Trabajo de Dimitruk — JavaScript asíncrono

## Presentación
Este proyecto contiene dos actividades prácticas sobre operaciones asíncronas en JavaScript. Los ejemplos utilizan situaciones simuladas para mostrar cómo se reciben resultados después de una espera.

## Actividad 1: Callbacks y Promises
Se compara una función callback, que se ejecuta cuando una tarea llega a cierto punto, con una Promise, que representa un resultado pendiente. También se muestran `then` y `catch` para continuar el proceso y tratar errores.

## Actividad 2: Promises, Async y Await
Se practica el uso de `async` y `await` para esperar resultados de forma legible. Además, se incluye `try/catch` para controlar fallos y `Promise.all` para esperar varias operaciones en paralelo.

## Cómo abrir el trabajo
1. Descomprimí la carpeta si recibiste el proyecto como ZIP.
2. Abrí el archivo `index.html` con un navegador.
3. Elegí una actividad desde el menú.
4. Leé la explicación y usá los botones para probar los ejemplos.

No hace falta instalar paquetes ni configurar un servidor.

## Cierre
Los callbacks y las Promises permiten organizar tareas que terminan en otro momento. `async/await` simplifica la lectura de ese tipo de código, mientras que `try/catch` y `Promise.all` ayudan a gestionar errores y resultados conjuntos.
